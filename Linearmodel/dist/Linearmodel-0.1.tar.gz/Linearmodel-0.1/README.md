# Linearmodel

Ce package contient des modules pour charger des données, effectuer des régressions linéaires, et visualiser les résultats.
