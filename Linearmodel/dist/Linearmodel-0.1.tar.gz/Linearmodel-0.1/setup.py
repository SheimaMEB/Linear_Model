from setuptools import setup, find_packages

setup(
    name='Linearmodel',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'pandas',
        'matplotlib'
    ],
    description='Un package pour effectuer des régressions linéaires et visualiser les résultats',
    author='Votre Nom',
    author_email='votre.email@example.com',
    url='https://votre-repo-url',  # Mettez ici l'URL de votre dépôt si vous en avez un
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)
